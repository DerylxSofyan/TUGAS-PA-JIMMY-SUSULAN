# Gilby-Rizki-XII-RPL-2
Tugas pak jimmy tentang Java
